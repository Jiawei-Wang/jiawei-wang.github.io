export * from './compiled-types/components/ProviderComponent';
export { default } from './compiled-types/components/ProviderComponent';